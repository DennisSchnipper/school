﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DierenAsiel
{
    public class Reservation
    {
        public Cat cat { get; }
        public Dog dog { get; }

        public void newCat(string name, Gender gender, string badHabits)
        {

        }

        public void newDog(string name, Gender gender)
        {

        }
    }
}
